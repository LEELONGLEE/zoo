﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.ZooManagement;

namespace Zoo.Interface
{
    public interface IAnimal
    {
        public string Name { get; set; }
        void Eat(Food food);
        void Sleep();
        void Bite(IAnimal animal);
        void Speak(string sound);
        void Create();
        void OnHaveFood(Cage sender, Food foodType);
        void OnBited();
    }
}
