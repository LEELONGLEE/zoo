﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Zoo
{
    public class ZooManager
    {
        public ZooManager() { }

        public Cage HandleCreateCage()
        {
            Cage cage = new Cage();

            cage.Create();

            return cage;
        }

        public List<Cage> RemoveCage(List<Cage> cages, int code)
        {
            var cage = FindCage(cages, code);
            bool removed = cages.Remove(cage);
            return cages;
        }

        public void RemoveAnimalFromCage(Cage cage, int code)
        {
            BaseAnimal animal = cage.animals.Where(a => a.Code == code).FirstOrDefault();

            if (animal == null)
                throw new ArgumentNullException("Animal không tồn tại");

            cage.DeleteAnimal(animal);
        }
        public void AddAnimalToCage(Cage cage, int chose)
        {
            BaseAnimal animal = null;
            switch (chose)
            {
                case 1:
                    animal = new Wolf();
                    animal.Create();
                    break;
                case 2:
                    animal = new Pig();
                    animal.Create();
                    break;
                case 3:
                    animal = new Monkey();
                    animal.Create();
                    break;
                case 4:
                    animal = new Parrot();
                    animal.Create();
                    break;
                default:
                    return;
            }

            cage.AddAnimal(animal);
        }

        public Cage FindCage(List<Cage> cages, int cageCode)
        {
            return cages.Where(c => c.Code.ToString().Equals(cageCode.ToString())).FirstOrDefault();
        }
        public void ShowInfoCages(List<Cage> cages)
        {
            Console.WriteLine("\n=========DANH SÁCH LỒNG==========");
            Console.WriteLine("Mã lồng\t\t\t\t\tTên Lòng");
            foreach (var cage in cages)
            {
                cage.ShowInfo();
            }
        }
        public List<Cage> InitCages()
        {
            List<Cage> cages = new List<Cage>();
            return cages;
        }

    }
}
