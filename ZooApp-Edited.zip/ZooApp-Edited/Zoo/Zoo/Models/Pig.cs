﻿using System;
using Zoo.Interface;
using Zoo.ZooManagement;

namespace Zoo
{
    public class Pig : Omnivore, IGluttony
    {
        public override string Sound { get; set; } = "Éc";

        public Pig() {
        
        }

        public override void Eat(Food food)
        {
            Console.WriteLine($"Pig-{Name} đang ăn {food}");
        }

        // Loài IGluttony thì có thể giành ăn bằng hành động Bite con vật khác
        public void FightForFood(IAnimal animal)
        {
            Bite(animal);
        }

        public override void OnOtherAnimalCry(BaseAnimal crier, string voice)
        {
            // không làm gì.
        }

        
    }
}
