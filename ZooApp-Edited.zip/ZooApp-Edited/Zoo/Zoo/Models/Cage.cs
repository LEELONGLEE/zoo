﻿using System;
using System.Collections.Generic;
using Zoo.Interface;
using Zoo.ZooManagement;

namespace Zoo
{
    // định nghĩa hàm xử lý sự kiện HaveFood, là một hàm có kiểu trả về void và kiểu đầu vào (Cage sender, Food foodType).
    public delegate void OnHaveFoodDelegate(Cage sender, Food foodType);


    // định nghĩa hàm xử lý sự kiện NewAnimal, là một hàm có kiểu trả về void và kiểu đầu vào (Cage sender, BaseAnimal newanimal).
    public delegate void OnNewAnimalDelegate(Cage sender, BaseAnimal newAnimal);

    public class Cage
    {
        private static int curID = 0;
        public static int GetNewID()
        {
            return curID++;
        }

        public event OnHaveFoodDelegate HaveFood;

        public event OnNewAnimalDelegate NewAnimal;

        #region properties
        public int Code { get; set; }
        public string Name { get; set; }
        public List<BaseAnimal> animals { get; set; } = new List<BaseAnimal>();
        public Cage() { }
        public Cage(int code, string name)
        {
            Code = code;
            Name = name;
        }
        #endregion properties

        public void TimeForEat(Food food)
        {
            HaveFood?.Invoke(this,food);
        }

        public void Create()
        {
            Console.WriteLine("Nhập thông tin để tạo Lồng");
            bool isValid = true;
            string input = string.Empty;

            Code = GetNewID();

            do
            {
                Console.WriteLine("Name: ");
                input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                    isValid = false;

            } while (!isValid);
            Name = input;

        }
        public void DeleteAnimal(BaseAnimal animal)
        {
            animals.Remove(animal);
            HaveFood -= animal.OnHaveFood;
            NewAnimal -= animal.OnNewAnimalInCase;
            foreach(var an in animals)
            {
                if (an != animal)
                {
                    // thú được remove thì bỏ đăng ký lắng nghe Cry trên các con vật khác. (Trường hợp này có thể thêm Event RemoveAnimal để remove event giống như NewAnimal)
                    an.Cry -= animal.OnOtherAnimalCry;
                    animal.Cry -= an.OnOtherAnimalCry;
                }
            }
        }

        public void AddAnimal(BaseAnimal animal)
        {
            // Con thú khi được add vào lồng sẽ lắng nghe sự kiện HaveFood của Cage. Khi HaveFood được invoke thì hàm xử lý xự kiện OnHaveFood() của
            // tất cả thú trong lồng sẽ được gọi.
            HaveFood += animal.OnHaveFood;

            // Cage phát sự kiện NewAnimal kèm theo object con thú được add vào cho tất cả con thú trong chuồng biết.
            NewAnimal?.Invoke(this, animal);

            // Con thú khi được add vào lồng sẽ lắng nghe sự kiện NewAnimal của Cage, để xử lý khi có con vật mới đc add vào.
            NewAnimal += animal.OnNewAnimalInCase;

            // thêm vào list animals của Cage
            animals.Add(animal);
        }

        public void ShowInfo()
        {
            Console.WriteLine($"{Code} | {Name}");
        }

        public void ShowInfoAnimals(List<BaseAnimal> animals)
        {
            Console.WriteLine("\n=========DANH SÁCH ĐỘNG VẬT==========");
            Console.WriteLine("\nMã động vật\t\t\t\t\t Tên động vật");
            foreach (var animal in animals)
            {
                animal.ShowInFo();
            }
        }

        public void FindAnimals()
        {
            Console.WriteLine("Tìm animal");
        }

        public BaseAnimal GetNearAnimal(BaseAnimal animal)
        {
            int t = 0;
            do
            {
                var id = new Random().Next(0, animals.Count);
                if(animals[id]!= animal)
                {
                    return animals[id];
                }
                t++;
            } while (t < 10);
            return null;
        }
    }
}
