﻿using System;
using Zoo.Interface;
using Zoo.ZooManagement;

namespace Zoo
{
    public class Monkey : Omnivore, IIntelligent
    {
        public override string Sound { get; set; } = "khỉ khỉ";
        public Monkey() {}
        
        public override void Eat(Food food)
        {
            Console.WriteLine($"Monkey-{Name} đang ăn {food}");
        }
        public override void Speak(string sound)
        {
            Console.WriteLine($"Monkey-{Name} kêu {sound}");
        }

        // Loài IIntelligent bắt chước tiếng kêu
        public void Copy(string skill)
        {
            Speak(skill);
        }

        // Xủ lý sự kiện Cry khi có con vật nào đó phát ra, Loài IIntelligent bắt chước tiếng kêu loài đó
        public override void OnOtherAnimalCry(BaseAnimal crier, string voice)
        {
            Copy(voice);
        }

    }
}
