﻿using System;
using Zoo.ZooManagement;

namespace Zoo
{
    public abstract class Herbivore : BaseAnimal
    {

        /// Kiểm tra xem có ăn được thức ăn này ko
        protected override bool CanEat(Food foodType)
        {
            // Động vật ăn hạt chỉ ăn hạt.
            return foodType == Food.Seed;
        }
    }
}
