﻿using System;
using Zoo.Interface;
using Zoo.ZooManagement;

namespace Zoo
{

    // định nghĩa hàm xử lý sự kiện Cry, là một hàm có kiểu trả về void và kiểu đầu vào (BaseAnimal sender, string voice).
    public delegate void AnimalCryDelegate(BaseAnimal sender, string voice);
    public abstract class BaseAnimal : IAnimal
    {
        #region properties

        // Sự kiện phát tiếng kiêu, cho phép các con vật lắng nghe.
        public event AnimalCryDelegate Cry;

        public int Code { get; set; }
        public string Name { get; set; }
        public virtual string Sound { get; set; }
        
        #endregion properties


        #region method

        private static int curID = 1; 
        public static int GetNewID()
        {
            return curID++;
        } 

        // Method Bite mô tả việc chủ động cắn của con vật này đối với con vật khác.
        public void Bite(IAnimal animal)
        {
            Console.WriteLine($"{this.GetType().Name} {Name} đang cắn {animal.GetType().Name} {animal.Name}");

            // Truyền thông điệp OnBite cho animal để xử lý thông điệp Bị Cắn.
            animal.OnBited();
        }

        // Method OnBite là xử lý việc con vật này bị cắn.
        public void OnBited()
        {
            Speak(Sound);
            Cry?.Invoke(this, Sound);
        }


        public virtual void Speak(string sound)
        {
            Console.WriteLine($"{this.GetType().Name} {this.Name} kêu {Sound}...");
        }


        /// <summary>
        /// My comment
        /// </summary>
        public void Sleep()
        {
            Console.WriteLine("Animal sleeping ...");
        }

        /// <summary>
        /// My comment
        /// </summary>
        public void ShowInFo()
        {
            Console.WriteLine($"{Code}\t\t\t\t | {Name}");
        }

        public virtual void Create()
        {
            bool isValid = true;
            string input = string.Empty;
            Code = GetNewID();
            do
            {
                Console.WriteLine("Nhập tên động vật: ");
                input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                    isValid = false;
            } while (!isValid);

            Name = input;
        }

        public void OnNewAnimalInCase(object sender, BaseAnimal newAnial)
        {
            // khi có con vật mới được thêm vào lồng, thì đăng ký lắng nghe sự kiện Cry của con vật đó
            newAnial.Cry += OnOtherAnimalCry;

            // ngược lại con vật mới được thêm vào lồng cũng lắng nghe sự kiện Cry của con vật này.
            this.Cry += newAnial.OnOtherAnimalCry;
        }


        /// Xử lý sự kiện HaveFood của Cage
        public void OnHaveFood(Cage sender, Food foodType)
        { 
            // Dùng hàm CanEat được override ở subclass, để kiểm tra Thú có ăn được thức ăn không.
            if (CanEat(foodType)) {
                // Dùng "is" để kiểm tra object có phải implement của IGluttony, nếu đúng thì dùng "as" để ép kiểu
                if (this is IGluttony)
                {
                    IGluttony gluttony = this as IGluttony;

                    var bited = sender.GetNearAnimal(this);
                    gluttony.FightForFood(bited);
                }
                // gọi hàm abstract Eat để thể hiện việc ăn khác nhau của từng loài.
                Eat(foodType);
            }
        }

         ///   Các hàm Abstract
        
        // abstract cách chọn thức ăn của từng loài
        protected abstract bool CanEat(Food foodType);

        // Xủ lý sự kiện Cry khi có con vật nào đó phát ra
        public abstract void OnOtherAnimalCry(BaseAnimal crier, string voice);

        // abstract cách ăn riêng của từng loài
        public abstract void Eat(Food food);

        #endregion method
    }
}
