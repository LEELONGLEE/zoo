﻿using System;
using Zoo.ZooManagement;

namespace Zoo
{
    public abstract class Carnivore : BaseAnimal
    {

        protected override bool CanEat( Food foodType)
        {
            // Động vật ăn thịt chỉ ăn thịt.
            return foodType == Food.Meat;
        }
    }
}
