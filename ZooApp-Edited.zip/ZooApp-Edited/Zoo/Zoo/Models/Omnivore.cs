﻿using System;
using Zoo.ZooManagement;

namespace Zoo
{
    public abstract class Omnivore : BaseAnimal
    {

        protected override bool CanEat(Food foodType)
        {
            // Động vật ăn tạp thì ắn tất cả.
            return true;
        }
    }
}
