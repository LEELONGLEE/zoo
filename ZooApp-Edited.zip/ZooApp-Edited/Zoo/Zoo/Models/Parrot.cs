﻿using System;
using Zoo.Interface;
using Zoo.ZooManagement;

namespace Zoo
{
    public class Parrot : Herbivore, IIntelligent
    {
        public override string Sound { get; set; } = "vẹt vẹt";

        public Parrot() {}
        
        public override void Eat(Food food)
        {
            Console.WriteLine($"Parrot-{Name} đang ăn {food}");
        }
        public override void Speak(string sound)
        {
            Console.WriteLine($"Parrot-{Name} kêu {sound}");
        }

        // Loài IIntelligent bắt chước tiếng kêu
        public void Copy(string skill)
        {
            Speak(skill);
        }

        // Xủ lý sự kiện Cry khi có con vật nào đó phát ra, Loài IIntelligent bắt chước tiếng kêu loài đó
        public override void OnOtherAnimalCry(BaseAnimal crier, string voice)
        {
            Copy(voice);
        }

    }
}
